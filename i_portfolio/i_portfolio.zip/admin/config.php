<?php
$connection= mysqli_connect('localhost','asad','','i_portfolio');#mysqli_connect('HostName','Username','Password','DB_Name');

?>