<?php
$connection= mysqli_connect('bookcellarbd.com','bookcell_asad_portfolio','asad2723171733','bookcell_i_portfolio'); #mysqli_connect('HostName','Username','Password','DB_Name');


?>