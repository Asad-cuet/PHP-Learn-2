<?php

$connection= mysqli_connect('bookcellarbd.com','bookcell_bookcell2','asad@$%1234','bookcell_book_cellar'); #mysqli_connect('HostName','Username','Password','DB_Name');

?>