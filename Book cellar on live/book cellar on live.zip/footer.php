


<div class="w3-container my-nevi w3-text-white" style="">
    <h2 class="my-text-yellow">About Us</h2>
    <p>A book venture formed by two students of DU with the vision to facilitate book lovers in their thirst for books. You can buy all kinds of books at a cheaper but higher discount</p>
    <h2 class="my-text-yellow">Contact Us</h2>
    <p><b>Cell:</b>01684604855</p>
    <p><b>Cell:</b>01716886379</p>
    <h2 class="my-text-yellow">Follow Us</h2>
    <a href="https://www.facebook.com/Book-Cellar-100582155165969" class="w3-blue w3-hover-red w3-margin-bottom w3-button"><i class="fa fa-facebook"></i> Facebook</a>
</div>






